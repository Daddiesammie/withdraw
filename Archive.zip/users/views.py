from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import User, Document, VerificationStatus
from django.http import HttpResponse
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.lib.units import inch
from io import BytesIO
from datetime import datetime
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')


from django.http import HttpResponse
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from io import BytesIO
from datetime import datetime

def download_receipt(request):
    buffer = BytesIO()
    
    # Document setup
    doc = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    
    # Colors
    BLUE_900 = colors.HexColor('#1e3a8a')
    GREEN_500 = colors.HexColor('#22c55e')
    GRAY_600 = colors.HexColor('#4b5563')
    WHITE = colors.white
    
    # Header section with blue background
    doc.setFillColor(BLUE_900)
    doc.rect(0, height-3*inch, width, 3*inch, fill=True)
    
    # Logo
    doc.setStrokeColor(WHITE)
    doc.rect(50, height-2.3*inch, 64, 64, stroke=True)
    doc.setFillColor(WHITE)
    doc.setFont("Helvetica", 12)
    doc.drawString(65, height-1.9*inch, "LOGO")
    
    # Header Text
    doc.setFont("Helvetica-Bold", 24)
    doc.drawCentredString(width/2, height-1.7*inch, "Verification Receipt")
    doc.setFont("Helvetica", 14)
    doc.drawCentredString(width/2, height-2*inch, "Official Withdrawal Documentation")
    
    # Verified Badge
    doc.setFillColor(GREEN_500)
    doc.roundRect(width-150, height-1.8*inch, 100, 30, 8, fill=True)
    doc.setFillColor(WHITE)
    doc.setFont("Helvetica-Bold", 12)
    doc.drawString(width-130, height-1.6*inch, "✓ VERIFIED")
    
    # Transaction Details Section
    doc.setFillColor(colors.black)
    doc.setFont("Helvetica-Bold", 16)
    doc.drawString(50, height-3.5*inch, "Transaction Details")
    
    # Details Box
    doc.setFillColor(colors.HexColor('#f9fafb'))
    doc.roundRect(50, height-6*inch, width-100, 2*inch, 8, fill=True)
    
    # Left Column
    y_position = height-4*inch
    doc.setFillColor(colors.black)
    doc.setFont("Helvetica", 11)
    left_details = [
        f"Transaction ID: #{request.user.id}{datetime.now().strftime('%Y%m%d')}",
        f"Date: {datetime.now().strftime('%B %d, %Y')}",
        f"Time: {datetime.now().strftime('%H:%M:%S')}",
        f"Account Holder: {request.user.get_full_name()}",
        f"Email: {request.user.email}"
    ]
    
    for detail in left_details:
        doc.drawString(70, y_position, detail)
        y_position -= 25
    
    # Right Column
    y_position = height-4*inch
    right_details = [
        f"Bank Name: {request.user.bank_name}",
        f"Account Number: ****{str(request.user.account_number)[-4:]}",
        f"Withdrawal Amount: ${request.user.withdrawal_amount:,.2f}",
        f"Processing Fee: $0.00",
        f"Total Amount: ${request.user.withdrawal_amount:,.2f}"
    ]
    
    for detail in right_details:
        doc.drawString(width/2 + 20, y_position, detail)
        y_position -= 25
    
    # Verification Steps
    doc.setFont("Helvetica-Bold", 16)
    doc.drawString(50, height-6.5*inch, "Verification Process Completed")
    
    steps = [
        ("Identity Verification", "Government ID and proof of address verified"),
        ("Tax Compliance", "Tax obligations verified and cleared"),
        ("Security Check", "Two-factor authentication completed"),
        ("Bank Verification", "Account ownership confirmed"),
        ("Final Approval", "Transaction approved by compliance team")
    ]
    
    y_position = height-7*inch
    for step, description in steps:
        # Green dot
        doc.setFillColor(GREEN_500)
        doc.circle(60, y_position+8, 4, fill=True)
        
        # Step title and description
        doc.setFillColor(colors.black)
        doc.setFont("Helvetica-Bold", 11)
        doc.drawString(80, y_position+5, step)
        doc.setFont("Helvetica", 9)
        doc.setFillColor(GRAY_600)
        doc.drawString(80, y_position-8, description)
        y_position -= 35
    
    # Signature Section
    doc.setFillColor(colors.black)
    doc.setFont("Helvetica-Bold", 12)
    doc.drawString(50, height-9.5*inch, "Client Signature")
    doc.line(50, height-9.7*inch, 250, height-9.7*inch)
    doc.setFont("Helvetica", 10)
    doc.drawString(50, height-9.9*inch, f"Date: {datetime.now().strftime('%B %d, %Y')}")
    
    # Footer
    doc.setFillColor(BLUE_900)
    doc.rect(0, 0, width, inch, fill=True)
    doc.setFillColor(WHITE)
    doc.setFont("Helvetica-Bold", 10)
    doc.drawString(50, 0.7*inch, "Contact Information")
    doc.setFont("Helvetica", 9)
    doc.drawString(50, 0.5*inch, "Email: support@yourcompany.com | Phone: +1 (555) 123-4567 | Website: www.yourcompany.com")
    doc.setFont("Helvetica", 8)
    doc.drawString(50, 0.3*inch, "This is an automatically generated receipt. Thank you for using our service.")
    
    doc.save()
    pdf = buffer.getvalue()
    buffer.close()
    
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="verification_receipt_{datetime.now().strftime("%Y%m%d")}.pdf"'
    response.write(pdf)
    
    return response



@login_required
def receipt_preview(request):
    context = {
        'current_date': datetime.now().strftime('%B %d, %Y'),
        'current_time': datetime.now().strftime('%H:%M:%S'),
        'verification_steps': [
            ("Identity Verification", "Government ID and proof of address verified"),
            ("Tax Compliance", "Tax obligations verified and cleared"),
            ("Security Check", "Two-factor authentication completed"),
            ("Bank Verification", "Account ownership confirmed"),
            ("Final Approval", "Transaction approved by compliance team")
        ]
    }
    return render(request, 'users/receipt_preview.html', context)

def verification_home(request):
    if not request.user.is_authenticated:
        return redirect('login')
    
    try:
        status = VerificationStatus.objects.get(user=request.user)
    except VerificationStatus.DoesNotExist:
        status = VerificationStatus.objects.create(user=request.user)
    
    context = {
        'progress': request.user.verification_progress,
        'status': status
    }
    return render(request, 'users/verification_home.html', context)

@login_required
def withdrawal_verification(request):
    if request.method == 'POST':
        otp = request.POST.get('withdrawal_otp')
        if otp == request.user.withdrawal_otp:
            status = VerificationStatus.objects.get(user=request.user)
            status.withdrawal_verified = True
            status.save()
            request.user.verification_progress = 25
            request.user.save()
            messages.success(request, 'Withdrawal OTP verified successfully!')
            return redirect('users:tax_verification')
        messages.error(request, 'Invalid OTP')
    return render(request, 'users/withdrawal_verification.html')

@login_required
def tax_verification(request):
    if request.method == 'POST':
        code = request.POST.get('tax_code')
        if code == request.user.tax_verification_code:
            status = VerificationStatus.objects.get(user=request.user)
            status.tax_verified = True
            status.save()
            request.user.verification_progress = 50
            request.user.save()
            messages.success(request, 'Tax verification completed successfully!')
            return redirect('users:identity_verification')
        messages.error(request, 'Invalid verification code')
    return render(request, 'users/tax_verification.html')

@login_required
def identity_verification(request):
    if request.method == 'POST':
        document = request.FILES.get('document')
        code = request.POST.get('identity_code')
        
        if document:
            Document.objects.create(user=request.user, document=document)
        
        if code == request.user.identity_verification_code:
            status = VerificationStatus.objects.get(user=request.user)
            status.identity_verified = True
            status.save()
            request.user.verification_progress = 75
            request.user.save()
            messages.success(request, 'Identity verification completed successfully!')
            return redirect('users:final_verification')
        messages.error(request, 'Invalid verification code')
    return render(request, 'users/identity_verification.html')

@login_required
def final_verification(request):
    if request.method == 'POST':
        code = request.POST.get('final_code')
        if code == request.user.final_verification_code:
            status = VerificationStatus.objects.get(user=request.user)
            status.final_verified = True
            status.save()
            request.user.verification_progress = 100
            request.user.is_verified = True
            request.user.save()
            messages.success(request, 'Final verification completed successfully!')
            return redirect('users:verification_complete')
        messages.error(request, 'Invalid verification code')
    return render(request, 'users/final_verification.html')

@login_required
def verification_complete(request):
    return render(request, 'users/verification_complete.html')




